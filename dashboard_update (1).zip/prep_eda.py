"""Menyiapkan ringkasan EDA dan statistik bintang dari data mentah Book-Crossing.
Jalankan sekali:  python prep_eda.py BX-Books.csv BX-Book-Ratings.csv BX-Users.csv
Output (taruh satu folder dengan app.py): eda_summary.json, book_stats.csv"""
import json, sys
import numpy as np, pandas as pd

fb, fr, fu = sys.argv[1:4]
out = sys.argv[4] if len(sys.argv) > 4 else "."
kw = dict(sep=";", encoding="latin-1", on_bad_lines="skip", dtype=str)
B, R, U = pd.read_csv(fb, **kw), pd.read_csv(fr, **kw), pd.read_csv(fu, **kw)
R["Book-Rating"] = pd.to_numeric(R["Book-Rating"], errors="coerce")
R = R.dropna(subset=["Book-Rating"])
E = R[R["Book-Rating"] > 0]

per_u, per_b = E.groupby("User-ID").size(), E.groupby("ISBN").size()
ub = pd.cut(per_u, [0, 1, 4, 9, 19, 49, 10**9], labels=["1", "2-4", "5-9", "10-19", "20-49", "50+"]).value_counts().sort_index()
bb = pd.cut(per_b, [0, 1, 4, 9, 19, 49, 10**9], labels=["1", "2-4", "5-9", "10-19", "20-49", "50+"]).value_counts().sort_index()

age = pd.to_numeric(U["Age"], errors="coerce")
va = age[(age >= 5) & (age <= 100)]
ah = pd.cut(va, range(5, 105, 5), right=False).value_counts().sort_index()
ctry = U["Location"].fillna("").str.split(",").str[-1].str.strip().str.title()
ctry = ctry[~ctry.isin(["", "N/A", "Unknown"])].value_counts().head(10)

yr = pd.to_numeric(B["Year-Of-Publication"], errors="coerce")
EB = E.merge(B[["ISBN", "Book-Author", "Publisher"]], on="ISBN")
au = EB.groupby("Book-Author").agg(readers=("User-ID", "nunique"), avg=("Book-Rating", "mean")).sort_values("readers", ascending=False).head(10)
pub = EB.groupby("Publisher").agg(readers=("User-ID", "nunique")).sort_values("readers", ascending=False).head(10)
dec = (yr[(yr >= 1950) & (yr <= 2005)] // 10 * 10).astype(int).value_counts().sort_index()

S = {
    "n_ratings": int(len(R)), "n_implicit": int((R["Book-Rating"] == 0).sum()), "n_explicit": int(len(E)),
    "n_users": int(len(U)), "n_books": int(len(B)), "n_users_explicit": int(per_u.size), "n_books_explicit": int(per_b.size),
    "mean_rating": float(E["Book-Rating"].mean()), "median_user": float(per_u.median()),
    "users_ge5": int((per_u >= 5).sum()), "books_ge10": int((per_b >= 10).sum()), "books_once": float((per_b == 1).mean()),
    "isbn_match": float(R["ISBN"].isin(B["ISBN"]).mean()), "age_missing": float(age.isna().mean()),
    "age_invalid": float(((age < 5) | (age > 100)).sum() / len(U)), "age_median": float(va.median()),
    "year_invalid": int(((yr == 0) | (yr > 2006) | yr.isna()).sum()),
    "sparsity": float(1 - len(E) / (per_u.size * per_b.size)),
    "rating_dist": {str(k): int(v) for k, v in E["Book-Rating"].astype(int).value_counts().sort_index().items()},
    "user_bins": {str(k): int(v) for k, v in ub.items()}, "book_bins": {str(k): int(v) for k, v in bb.items()},
    "age_hist": {f"{int(i.left)}": int(v) for i, v in ah.items()},
    "countries": {k: int(v) for k, v in ctry.items()},
    "authors": [{"author": k, "readers": int(r.readers), "avg": round(float(r.avg), 2)} for k, r in au.iterrows()],
    "publishers": [{"publisher": k, "readers": int(r.readers)} for k, r in pub.iterrows()],
    "decades": {str(k): int(v) for k, v in dec.items()},
}
json.dump(S, open(f"{out}/eda_summary.json", "w"), indent=1)

# Bintang 1-5 dari seluruh rating eksplisit (rating umum), Bayesian weighted
C, m = E["Book-Rating"].mean(), 10
g = E.groupby("ISBN")["Book-Rating"].agg(n="size", avg="mean")
g["bayes"] = (g.n / (g.n + m)) * g.avg + (m / (g.n + m)) * C
g["stars"] = (g["avg"] / 2).round(2)
g = g.reset_index().merge(B[["ISBN", "Book-Title", "Book-Author", "Year-Of-Publication", "Publisher", "Image-URL-M", "Image-URL-L"]], on="ISBN", how="left")
keep = set(pd.read_pickle(f"{out}/candidate_books.pkl")["ISBN"].astype(str)) | set(pd.read_csv(f"{out}/popular_books.csv", dtype={"ISBN": str})["ISBN"])
g = g[g["ISBN"].isin(keep)]
g.round(4).to_csv(f"{out}/book_stats.csv", index=False)
print(len(g), "buku;", json.dumps({k: v for k, v in S.items() if not isinstance(v, (dict, list))}, indent=0))
